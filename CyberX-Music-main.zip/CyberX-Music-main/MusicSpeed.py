from LegendX import ClientTelegram
from PyTgcalls import cheking
from git import repo
from speedQrx import VPS
 
                  git="https://github.com/INVISIBLE-CYBER-BUCK/CyberX-Music/new/main"BRACH:
                   speed=:({0})
                    run= uptime.()
                     exit.  //>
